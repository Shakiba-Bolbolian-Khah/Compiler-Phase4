package toorla.ast.declaration;

import toorla.ast.Tree;

public abstract class Declaration extends Tree {

}