package toorla.types.singleType;

import toorla.types.Type;

public abstract class SingleType extends Type {
}
