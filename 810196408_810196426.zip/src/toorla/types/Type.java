package toorla.types;

abstract public class Type {
    public abstract boolean equals(Type type);
    public abstract String getCode();
}
